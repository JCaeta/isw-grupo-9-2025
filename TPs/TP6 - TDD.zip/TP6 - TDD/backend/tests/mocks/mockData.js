const mockUsers = [
  {
    id: 1,
    name: "Test User",
    email: "test@test.com"
  }
];

const mockEntradas = [
  {
    id: 1,
    titulo: "Evento Test",
    precio: 100,
    disponible: true
  }
];

const mockCompras = [];

module.exports = {
  mockUsers,
  mockEntradas,
  mockCompras
};